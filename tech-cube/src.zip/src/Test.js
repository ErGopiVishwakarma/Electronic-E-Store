import React from 'react'

const arr = [
    {
        "name": "Juri Kalita",
        "mobile": "2345289873",
        "email": "juri123@gmail.com",
        "password": "juri123",
        "pic": "https://user-images.githubusercontent.com/68116821/236767880-bc7530c3-07e1-4ca3-a92b-d968494b4e66.png",
        "id": 3
      },
      {
        "name": "Tanmoy Roy",
        "mobile": "9093141115",
        "email": "tanmoy123@gmail.com",
        "password": "tanmoy123",
        "pic": "https://avatars.githubusercontent.com/u/115494445?v=4",
        "id": 4
      },
      {
        "name": "Deepak Yadav",
        "mobile": "4152896354",
        "email": "deepak123@gmail.com",
        "password": "deepak123",
        "pic": "https://avatars.githubusercontent.com/u/112754831?v=4",
        "id": 5
      }
]

const Test = () => {

    for(let e of arr){
        console.log(e)
    }

  return (
    <div>Test</div>
  )
}

export default Test