export const Dash = 'Dash'
export const Admin = 'Admin'
export const User = 'User'
export const Product = 'Product'
export const UserProfile ="UserProfile"
export const AdminProfile ="AdminProfile"
export const AllProductData ="AllProductData"
export const GetDataFromBlackList = "GetDataFromBlacklist"
export const PostDataToBlacklist = "PostDataToBlacklist"
export const DeleteDataFromBlacklist = "DeleteDataFromBlacklist"

